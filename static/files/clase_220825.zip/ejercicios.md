# Ejercicios
## Ejercicio 1
Crear una calculadora que nos permita sumar, restar, multiplicar y dividir con el siguiente formato:
```bash
./calculadora.sh operacion numero_1 numero_2
```
Y muestre los valores por pantalla.
Ejemplos:
```bash
./calculadora.sh suma 33 66
# Se debe mostrar por pantalla 99

./calculadora.sh resta 66 22
# Se debe mostrar por pantalla 44
```

## Ejercicio 2
Agregarle a la calculadora una función que nos diga la tabla (del 1 al 10) del número que nosotros le pasemos como argumento.
Ejemplo:
```bash
./calculadora.sh tabla 7
# Se debe mostrar por pantalla:
# 7 x 1 = 7
# 7 x 2 = 14
# 7 x 3 = 21
# 7 x 4 = 28
# 7 x 5 = 35
# 7 x 6 = 42
# 7 x 7 = 49
# 7 x 8 = 56
# 7 x 9 = 63
# 7 x 10 = 70
```

## Ejercicio 3
Crear un programa que reciba una lista de nombres y cree directorios dentro de la carpeta actual, con esos nombres.
Ejemplo:
```bash
./crear_directorios.sh aqui me pongo a cantar al compas de la viguela
# Al hacer ls en el directorio actual, debería ver (por lo menos) los siguientes directorios:
# a
# al
# aqui
# cantar 
# compas
# de
# la
# me
# pongo
# viguela
```
