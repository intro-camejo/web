#!/bin/bash

operador=$1
operando1=$2
operando2=$3

function tabla() {
    local numero=$1
    for i in {1..10}; do
        echo "$numero x $i: $(($i * $numero))"
    done
}

if [ "$operador" == "+" ]; then
    echo $(( $operando1 + $operando2 ))
elif [ "$operador" == "-" ]; then
    echo $(( $operando1 - $operando2 ))
elif [ "$operador" == "*" ]; then
    echo $(( $operando1 * $operando2 ))
elif [ "$operador" == "tabla" -a $# -eq 2 ]; then
    tabla $operando1
elif [ "$operador" == "/" -a "$operando2" -ne 0 ]; then
    echo $(( $operando1 / $operando2 ))
fi
