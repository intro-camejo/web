#!/bin/bash

for palabra in $@; do
    mkdir $palabra
done
