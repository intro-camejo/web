#!/bin/bash

# ----------------------------------------------------------------------------------------------------------------------------------------------------


# 1. Un script notas.sh que reciba un número (0–10) y diga si Lara aprobó o desaprobó.

# -> Verificamos si pasan el arg
# -> Verificamos que sea del 0-10
# -> Comparamos

# if [ $# -ne 1 ]; then
#     echo "¿Y la nota?"
#     exit 1
# fi

# nota=$1

# if [[ ! $nota =~ ^[0-$9]+ ]]; then
#     echo "No es un numero"
#     exit 1 
# fi

# if [[ $nota -lt 1 || $nota -gt 10 ]]; then
#     echo "La nota no esta entre 0 y 10"
#     exit 1
# fi

# if [ $nota -lt 4 ]; then
#     echo "Larita has desaprobado :'("
# else
#     echo "Larita aprobaste!"
# fi



# ----------------------------------------------------------------------------------------------------------------------------------------------------

# 2. En la materia de Intro, los Manus estaban cansados de que los estudiantes usaran contraseñas poco seguras como 1234, hola, o incluso "contraseña" para 
# Algotron.

# Por eso, un buen día, se reunieron los colabs mas mas mas mas mas mas mas cracks de toda la facultad:

#          -> Manu C, que siempre decía: "Aguante San lorenzo"....digo “si no hay un if, no es divertido”.

#          -> Nico, el fan de Bash que ponía echo hasta en los apuntes.

#          -> Peke, que intentaba adivinar contraseñas con fuerza bruta, pero siempre terminaba bloqueada.

#          -> Gonza, que quería aplicar expresiones regulares a absolutamente todo (“regex o nada”).

#          -> Manu B, que insistía en que “todo esto debería correr también en Docker”.

# Decidieron crear un script de Bash para validar contraseñas de los estudiantes.

# El script recibe el nombre de un alumno y el csv donde esta la lista de nombres y su contraseña (en texto plano :0 ) y debe asegurarse de que la contraseña tuviera:

# al menos 1 letra minúscula (para los simples como Nico),

# al menos 1 letra mayúscula (para los gritones como Manu C),

# al menos 1 número (para los que hacen cuentas con los feriados como Peke),

# y al menos 1 caracter especial: @!&$%? (para ser kpos como Manu B).

# TIP: Encapsular la lógica de la validación en una Funcion!!

# ¿Que pasa si no me pasan alguno de mis argumentos...?


# if [ $# -ne 2 ]; then
#     echo "Cantidad de argumentos erronea"
#     exit 1
# fi

# alumno=$1
# archivo=$2

# function validar_contrasena() {
#     contrasena=$1
#     if [[ \
#         $contrasena =~ [a-z]+ && \
#         $contrasena =~ [A-Z] && \
#         $contrasena =~ [0-9] && \
#         $contrasena =~ [\@\!\&\$\%\?] \
#     ]]; then
#         echo "Contraseña valida"
#     else
#         echo "Contraseña invalida"
#     fi
# }

# function buscar_contrasena() {
#     grep "^$alumno," $archivo | cut -d , -f 2
# }

# contrasena_encontrada=$(buscar_contrasena)
# if [ ! $contrasena_encontrada ]; then
#     echo El alumno no existe
#     exit 1
# fi

# validar_contrasena $contrasena_encontrada



# ----------------------------------------------------------------------------------------------------------------------------------------------------


# 3. En una tarde de práctica de Bash, Pedro tuvo una GRAN idea: ¿Y si armamos un menú interactivo para manejar a nuestros alumnos en el archivo alumnos.csv?

# A Sofi le encantó la idea porque siempre se olvidaba cuántos usuarios había cargados.
# Peke, como buena vieja chusma, quería un buscador para encontrar rápido si alguien ya estaba registrado.
# Mientras tanto, Conra insistía en que lo más importante era validar que las contraseñas cumplan con las reglas de seguridad (aunque siempre se olvidaba la suya ).
# Manu R y Manu B solo miraban y decían: "Bueno, pero que sea fácil de usar, ¡con un menú clarito!"

# El script menu_amigos.sh que muestra un menú interactivo y permite al usuario elegir 
# entre distintas opciones para agregar (que NO haya repetidos eh), eliminar, buscar, contar o validar usuarios del archivo.

archivo=$1

function imprimir_ayuda() {
    echo "Menu interactivo. Elegi tu opcion:"
    echo "1) agregar alumno"
    echo "2) buscar alumno"
    echo "3) validar contraseña de alumno"
    echo "4) eliminar alumno"
    echo "5) salir"
}

imprimir_ayuda
read opcion
while [ $opcion -ne 5 ]; do
    # Agregar alumno
    if [ $opcion -eq 1 ]; then
        read -p "Nombre del alumno: " alumno
        read -p "Contraseña (te prometo que no te la robo): " contrasena
        echo "$alumno,$contrasena" >> $archivo
    # Buscar alumno
    elif [ $opcion -eq 2 ]; then
        read -p "Nombre del alumno: " alumno
        alumno_encontrado=$(grep "^$alumno," $archivo)
        if [ "$alumno_encontrado" != "" ]; then
            echo El alumno existe
        else
            echo El alumno no existe
        fi
    # Validar contraseña de alumno
    elif [ $opcion -eq 3 ]; then
        echo Opcion 3
    # Eliminar alumno
    elif [ $opcion -eq 4 ]; then
        read -p "Nombre del alumno: " alumno
        grep -v "^$alumno," $archivo > .temp
        mv .temp $archivo
    else
        echo "Opcion invalida"
    fi

    imprimir_ayuda
    read opcion
done


