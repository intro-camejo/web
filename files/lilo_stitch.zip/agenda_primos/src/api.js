// import express from "express";
// import cousins from "../data/cousins.json" with { type: "json" };
const express = require("express");
const cousins = require("../data/cousins.json");

const app = express();
const port = 3030;

app.use(express.json());

// GET. /cousins
app.get("/api/v1/cousins", (req, res) => {
  res.json(cousins);
});

// GET. /cousins/<num>
app.get("/api/v1/cousins/:num", (req, res) => {
  let cousin = cousins[req.params.num];

  if (cousin === undefined) {
    res.sendStatus(404);
  }

  cousin["number"] = req.params.num;

  res.json(cousin);
});

// POST. /cousins
app.post("/api/v1/cousins", (req, res) => {
  if (req.body === undefined) {
    return res.status(400).send("No body was provided");
  }

  const number = req.body.number;
  const name = req.body.name;
  const podColor = req.body.podColor;
  const description = req.body.description;

  if (number === undefined) {
    return res.status(400).send("Number not provided");
  }

  if (cousins[number] !== undefined) {
    return res.status(409).send("The cousin already exists");
  }

  if (name === undefined) {
    return res.status(400).send("Name not provided");
  }

  if (podColor === undefined) {
    return res.status(400).send("Pod color not provided");
  }

  if (description === undefined) {
    return res.status(400).send("Description not provided");
  }

  cousins[number] = {
    name: name,
    podColor: podColor,
    description: description,
  };

  res.status(201).json(cousins[number]);
});

// DELETE. /cousins/<num>
app.delete("/api/v1/cousins/:num", (req, res) => {
  const cousin = cousins[req.params.num];

  if (cousin === undefined) {
    return res.sendStatus(404);
  }

  cousins[req.params.num] = undefined;

  return res.json(cousin);
});

// PUT. /cousins/<num>
app.put("/api/v1/cousins/:num", (req, res) => {
  let cousin = cousins[req.params.num];

  if (cousin === undefined) {
    return res.sendStatus(404);
  }

  if (req.body === undefined) {
    return res.status(400).send("No body was provided");
  }

  const name = req.body.name;
  const podColor = req.body.podColor;
  const description = req.body.description;

  if (name === undefined) {
    return res.status(400).send("Name not provided");
  }

  if (podColor === undefined) {
    return res.status(400).send("Pod color not provided");
  }

  if (description === undefined) {
    return res.status(400).send("Description not provided");
  }

  cousins[req.params.num] = {
    name: name,
    podColor: podColor,
    description: description,
  };

  res.json(cousins[req.params.num]);
});

app.listen(port, () => {
  console.log(`Server initiated at port ${port}`);
});
